chat server/client from: https://medium.com/swlh/lets-write-a-chat-app-in-python-f6783a9ac170
chat-server: https://gist.github.com/schedutron/cd925247bfc4f8ae7930bbd99984a441#file-chat_serv-py
chat-client: https://gist.github.com/schedutron/287324944d765ae0656eec6971ca40d8#file-chat_clnt-py

demo is using tkinter and threading.
how to run the demo:
1.) pyhton3 chat_serv.py
2.) (in new terminal!) python3 chat_clnt.py
enter in terminal:
host: 127.0.0.1
port: 33.000

3.) repeat step 2 in another terminal
4.) both clients can now chat by typing in the tkinter interface