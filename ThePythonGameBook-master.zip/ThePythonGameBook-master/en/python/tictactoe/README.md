# Backlinks Plugin for DokuWiki

Add lists of backlinks to a page.

All documentation for the Backlinks Plugin is available online at: http://dokuwiki.org/plugin:backlinks

See COPYING for license info.

[![Build Status](https://travis-ci.org/mprins/dokuwiki-plugin-backlinks.svg?branch=master)](https://travis-ci.org/mprins/dokuwiki-plugin-backlinks)
[![Scrutinizer Code Quality](https://scrutinizer-ci.com/g/mprins/dokuwiki-plugin-backlinks/badges/quality-score.png?b=master)](https://scrutinizer-ci.com/g/mprins/dokuwiki-plugin-backlinks/?branch=master)
[![GitHub issues](https://img.shields.io/github/issues/mprins/dokuwiki-plugin-backlinks.svg)](https://github.com/mprins/dokuwiki-plugin-backlinks/issues)
[![GitHub forks](https://img.shields.io/github/forks/mprins/dokuwiki-plugin-backlinks.svg)](https://github.com/mprins/dokuwiki-plugin-backlinks/network)
[![GitHub stars](https://img.shields.io/github/stars/mprins/dokuwiki-plugin-backlinks.svg)](https://github.com/mprins/dokuwiki-plugin-backlinks/stargazers)
[![GitHub license](https://img.shields.io/badge/license-GPLv2-blue.svg)](https://raw.githubusercontent.com/mprins/dokuwiki-plugin-backlinks/master/COPYING)
