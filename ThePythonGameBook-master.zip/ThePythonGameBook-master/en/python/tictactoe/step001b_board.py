print("[ ] [ ] [ ]\n" * 3) # all in one-line
