"""desired display of board"""
board=r"""
r\c 0:  1:  2:
0: [ ] [ ] [ ]
1: [ ] [ ] [ ]
2: [ ] [ ] [ ]"""
print(board)
