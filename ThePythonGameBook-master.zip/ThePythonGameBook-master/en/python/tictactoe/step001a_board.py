board = """
[ ] [ ] [ ]
[ ] [ ] [ ]
[ ] [ ] [ ]"""
print(board)


