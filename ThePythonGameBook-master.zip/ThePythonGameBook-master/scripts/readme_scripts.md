content of scripts:
Those are various helper scripts for producing the Dokuwiki content for ThePythonGameBook.

  * differ.py: 
    * source: https://github.com/wagoodman/diff2HtmlCompare
    * usage: call with 2 pyhton files as parameters, creates a nice static html page of the diff
  