readme for ThePythonGameBook on Github.com

the idea of this project is to host and sync source code and files for

ThePythonGameBook.com ( http://ThePythonGameBook.com ) 

For questions, please write an email to horstjens@gmail.com


### state of ThePythonGameBook
  
  * en:python:    ok
  * en:glossary:            ok
  * en:pygame:             need cleanup


### file and folder structure:

This Github repository reflects the file and folder structure of ThePythonGameBook's dokuwiki:

The dokuwiki structure is a bit more complex, because it split' into a 'data' folder for the text of the dokuwiki pages and into a seperate 'media' folder for images etc. Each folder has a top language folder (en, fr, de etc.). As for the moment (2020-05) only the English language part of Dokuwiki is activley maintained the 'en' folder is the only one mirrored into Github.
In this Github repository, everything necessary to create a wiki page (data, media, external html) is merged into the same folder.

